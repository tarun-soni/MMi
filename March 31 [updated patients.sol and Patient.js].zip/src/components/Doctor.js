import React from 'react';
import './App.css';

function Doctor() {
  return (
    <div>
      <h1> Doctor DashBoard </h1>
    </div>
  );
}

export default Doctor;
